# GDC STYLE AI Kit

AI Ready — create and validate GDC STYLE recipes with Claude, ChatGPT, Gemini or other compatible agents. Applying them in DaVinci Resolve stays under your control.

Read: `docs/README.en.md` · `docs/README.ro.md` · `docs/README.es.md` · `CAPABILITIES.md`.
Folders: `claude-code/`, `codex/` (native skills), `portable/` (ChatGPT, Gemini, generic), `schemas/`, `examples/`. `manifest.json` lists every file with its SHA-256.
