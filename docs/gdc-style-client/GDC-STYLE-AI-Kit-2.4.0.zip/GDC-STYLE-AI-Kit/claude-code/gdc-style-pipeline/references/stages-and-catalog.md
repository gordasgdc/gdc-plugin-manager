# Stages, management modes and the catalog

## The chain (fixed order, checked by the engine)

`camera source` → **Input Transform** (GDC product, licensable; only when GDC manages colour) → **Linear tools** (scene-linear) → **Linear to Log** (GDC product, licensable) → **Log and Film tools** → **DRT** (output transform, always last).

| Stage | Products (slug) | Notes |
|---|---|---|
| Linear | `exposure-balance`, `optics` | before Linear to Log |
| Log / Film | `color`, `look`, `skin`, `highlights-gamut`, `film` | after Linear to Log; Film after the tonal tools |
| Output | `drt` | declared in `outputTransform`, never in a tool list |
| Pipeline stages | `input-transform`, `linear-to-log` | licensable products, declared in their own fields (`inputTransform`, `linearToLog`), never in a tool list; each needs an edition (`demo` or `full`) in `license.editions`; installed from the GDC STYLE Client, Instruments, section Pipeline components |

Always read the live list with the `catalog` operation: it is the source of truth (names, versions, public controls, ranges, units, options, cameras, working profiles). Products flagged `usable: false` are not available in a recipe.

## Who manages colour

- `gdc-managed`: the clip enters Resolve unchanged; GDC Input Transform (with a `camera` from the catalog) and GDC Linear to Log do the transforms. No Resolve IDT or Color Space Transform on the clip.
- `resolve-managed`: Resolve (Color Management, a Color Space Transform, or the ACES input transform) already delivers the working space. Say what it delivers:
  - `delivers: linear` (scene-linear of the working profile): the recipe has GDC Linear to Log, no Input Transform.
  - `delivers: log` (for example ACEScct): no Input Transform and no Linear to Log. If there are Linear tools, the Linear stage sits between two Color Space Transforms made in Resolve (`linearStageCst`); that is a manual step.
- Doubling a transform Resolve already does is refused with `V3P-DOUBLE-TRANSFORM`.

## Working profile (the pipeline)

One profile per chain, taken from the catalog (`ap1-acescct`, `dwg-davinci-intermediate`, `awg3-logc3-ei800`, `awg4-logc4`). All nodes of a chain share it. If the user does not know, propose the one that fits the source and say why.

## Parameters

Only public controls listed by `catalog` can be set, by their stable `name`, inside `params`. A slider takes a number inside `min` and `max` (the `unit` says stops, mired, points and so on when the label states it); a toggle takes true or false; a choice takes an index or the exact label. Hidden states, buttons, notes and the diagnostic View are never set.

## Output

`outputTransform.provider: gdc` means GDC DRT (SDR Rec.709 Gamma 2.4 is the only target). `provider: resolve` means Resolve converts for display and GDC adds no output node.
