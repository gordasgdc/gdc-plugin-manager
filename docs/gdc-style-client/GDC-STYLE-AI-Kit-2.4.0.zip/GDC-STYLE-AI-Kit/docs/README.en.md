# GDC STYLE AI Kit

**AI Ready** — create and validate GDC STYLE recipes with Claude, ChatGPT, Gemini or other compatible agents. Applying them in DaVinci Resolve stays under your control.

## What this is
A set of public files (skills, instructions, schemas, examples) that teach an AI assistant to use the local helper installed with GDC STYLE Client. The assistant builds a **recipe** (the chain of GDC tools, in the right order, with valid parameters), the engine checks it, and you get a readable plan with the exact steps to follow in Resolve.

## What it is not
It does not drive DaVinci Resolve (its scripting cannot create OpenFX nodes or set OpenFX parameters). It never changes licences, editions or the Demo watermark. Confirmation is always yours.

## Install
- **Claude Code / Codex:** open GDC STYLE Client → **AI Ready** → *Install skill for Claude Code* / *Install skill for Codex*. The Client shows the exact destination first and asks for confirmation; an existing skill is backed up, never overwritten silently.
- **ChatGPT / Gemini / others:** in the Client press *Export universal kit* (or unzip this archive) and follow `portable/chatgpt/`, `portable/gemini/` or `portable/INSTRUCTIONS.generic.md`. These platforms have no native install for local tools: see `CAPABILITIES.md` for what each can do.

## Use
Ask the assistant for a pipeline ("ARRI LogC4 footage, natural skin, Rec.709 delivery, GDC manages colour"). It reads the catalogue, builds and validates the recipe and shows the plan. To "apply", the assistant asks you to run `confirm` in your own terminal, read the plan and type the phrase; the recorded result is a simulation and a checklist: you mount the nodes in Resolve.

## Update
Updating GDC STYLE Client updates the helper. The skill folders are replaced from the Client's AI Ready screen (*Update skills*; your previous copy is backed up). Re-export the universal kit after an update.

## Uninstall
AI Ready → *Remove skills installed by the Client*. Or run `uninstall.sh` from this kit. Only folders carrying the Kit marker are removed.

## Safety
The helper works without administrator rights, without network access and without reading your files. Recipes cannot carry licence data, keys, addresses or paths. Text inside project names or notes is treated as data, never as instructions.
