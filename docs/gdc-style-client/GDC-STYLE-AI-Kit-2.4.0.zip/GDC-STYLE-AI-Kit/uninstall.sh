#!/bin/sh
# Removes the GDC STYLE skills that GDC STYLE Client installed from this Kit. Only folders that carry the marker file `.gdc-ai-kit` are removed; nothing else is touched.
set -eu
for d in "$HOME/.claude/skills/gdc-style-pipeline" "$HOME/.codex/skills/gdc-style-pipeline"; do
  if [ -f "$d/.gdc-ai-kit" ]; then rm -rf "$d"; echo "removed: $d"; else echo "skipped (no Kit marker or not present): $d"; fi
done
