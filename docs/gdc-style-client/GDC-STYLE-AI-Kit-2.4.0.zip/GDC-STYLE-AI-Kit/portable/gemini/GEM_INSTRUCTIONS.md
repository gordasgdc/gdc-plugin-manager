# Gemini (Gem)

Gemini has no native installer for local tools.

1. Create a Gem. Paste `../INSTRUCTIONS.generic.md` as the instructions.
2. Attach `../PROTOCOL.md`, the files of `../../schemas/` and `../../examples/`.
3. Same two-step workflow as ChatGPT: the Gem writes the JSON request, you run `gdc-style-ai request --request - --compact` and paste the answer back. Never paste licences, keys, paths or private addresses.
4. Confirmation (`gdc-style-ai confirm`) is yours, in your terminal.

This is a copy-and-paste workflow, not a live integration.
