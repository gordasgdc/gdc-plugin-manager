# ChatGPT (custom GPT or project)

ChatGPT has no native installer for local tools, and a custom GPT cannot run a local command.

1. Create a custom GPT (or a project). Paste `../INSTRUCTIONS.generic.md` as the instructions.
2. Upload as knowledge files: `../PROTOCOL.md`, everything in `../../schemas/` and `../../examples/`, and the three files of `references/` (also in `../INSTRUCTIONS.generic.md`'s folder of the skill).
3. Work in two steps: the GPT writes the JSON request; you run `gdc-style-ai request --request - --compact` in Terminal, paste the request, and paste the JSON answer back. Never paste licences, keys, paths or private addresses.
4. Confirmation (`gdc-style-ai confirm`) is yours, in your terminal.

This is a copy-and-paste workflow, not a live integration.
