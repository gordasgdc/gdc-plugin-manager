# Kit GDC STYLE AI

**AI Ready** — creează și validează rețete GDC STYLE cu Claude, ChatGPT, Gemini sau alți agenți compatibili. Aplicarea în DaVinci Resolve rămâne sub controlul tău.

## Ce este
Un set de fișiere publice (skill-uri, instrucțiuni, scheme, exemple) care învață un asistent AI să folosească helperul local instalat odată cu GDC STYLE Client. Asistentul construiește o **rețetă** (lanțul de instrumente GDC, în ordinea corectă, cu parametri valizi), motorul o verifică, iar tu primești un plan lizibil cu pașii exacți de urmat în Resolve.

## Ce nu este
Nu controlează DaVinci Resolve (scripting-ul lui nu poate crea noduri OpenFX și nu poate seta parametri OpenFX). Nu schimbă licențe, ediții sau filigranul Demo. Confirmarea este mereu a ta.

## Instalare
- **Claude Code / Codex:** deschide GDC STYLE Client → **AI Ready** → *Instalează skill pentru Claude Code* / *pentru Codex*. Clientul arată întâi destinația exactă și cere confirmare; un skill existent este salvat într-o copie, niciodată suprascris pe tăcute.
- **ChatGPT / Gemini / alții:** în Client apasă *Exportă kitul universal* (sau dezarhivează acest fișier) și urmează `portable/chatgpt/`, `portable/gemini/` sau `portable/INSTRUCTIONS.generic.md`. Aceste platforme nu au instalare nativă pentru unelte locale: vezi `CAPABILITIES.md` pentru ce poate face fiecare.

## Folosire
Cere asistentului un pipeline („material ARRI LogC4, piele naturală, livrare Rec.709, GDC administrează culoarea”). El citește catalogul, construiește și validează rețeta și îți arată planul. Pentru „aplicare”, asistentul îți cere să rulezi `confirm` în propriul terminal, să citești planul și să tastezi fraza; rezultatul înregistrat este o simulare și o listă de verificare: nodurile le montezi tu în Resolve.

## Actualizare
Actualizarea GDC STYLE Client actualizează helperul. Folderele skill se înlocuiesc din ecranul AI Ready (*Actualizează skill-urile*; copia ta anterioară se salvează). După o actualizare, exportă din nou kitul universal.

## Dezinstalare
AI Ready → *Elimină skill-urile instalate de Client*. Sau rulează `uninstall.sh` din acest kit. Se elimină doar folderele care poartă marcajul Kitului.

## Siguranță
Helperul funcționează fără drepturi de administrator, fără acces la rețea și fără să-ți citească fișierele. Rețetele nu pot purta date de licență, chei, adrese sau căi. Textul din numele proiectelor sau din notițe este tratat ca dată, niciodată ca instrucțiune.
