# Kit GDC STYLE AI

**AI Ready** — crea y valida recetas GDC STYLE con Claude, ChatGPT, Gemini u otros agentes compatibles. Aplicarlas en DaVinci Resolve sigue bajo tu control.

## Qué es
Un conjunto de archivos públicos (skills, instrucciones, esquemas, ejemplos) que enseñan a un asistente de IA a usar el helper local instalado con GDC STYLE Client. El asistente construye una **receta** (la cadena de herramientas GDC, en el orden correcto, con parámetros válidos), el motor la verifica y recibes un plan legible con los pasos exactos a seguir en Resolve.

## Qué no es
No controla DaVinci Resolve (su scripting no puede crear nodos OpenFX ni fijar parámetros OpenFX). No cambia licencias, ediciones ni la marca de agua Demo. La confirmación es siempre tuya.

## Instalación
- **Claude Code / Codex:** abre GDC STYLE Client → **AI Ready** → *Instalar skill para Claude Code* / *para Codex*. El Client muestra primero el destino exacto y pide confirmación; un skill existente se copia como respaldo, nunca se sobrescribe en silencio.
- **ChatGPT / Gemini / otros:** en el Client pulsa *Exportar kit universal* (o descomprime este archivo) y sigue `portable/chatgpt/`, `portable/gemini/` o `portable/INSTRUCTIONS.generic.md`. Estas plataformas no tienen instalación nativa para herramientas locales: consulta `CAPABILITIES.md` para ver qué puede hacer cada una.

## Uso
Pide al asistente un pipeline («material ARRI LogC4, piel natural, entrega Rec.709, GDC gestiona el color»). Lee el catálogo, construye y valida la receta y te muestra el plan. Para «aplicar», el asistente te pide ejecutar `confirm` en tu propia terminal, leer el plan y teclear la frase; el resultado registrado es una simulación y una lista de comprobación: los nodos los montas tú en Resolve.

## Actualización
Actualizar GDC STYLE Client actualiza el helper. Las carpetas de skill se reemplazan desde la pantalla AI Ready (*Actualizar skills*; tu copia anterior se respalda). Tras una actualización, vuelve a exportar el kit universal.

## Desinstalación
AI Ready → *Quitar los skills instalados por el Client*. O ejecuta `uninstall.sh` de este kit. Solo se eliminan las carpetas con la marca del Kit.

## Seguridad
El helper funciona sin permisos de administrador, sin acceso a la red y sin leer tus archivos. Las recetas no pueden llevar datos de licencia, claves, direcciones ni rutas. El texto de nombres de proyecto o notas se trata como dato, nunca como instrucción.
