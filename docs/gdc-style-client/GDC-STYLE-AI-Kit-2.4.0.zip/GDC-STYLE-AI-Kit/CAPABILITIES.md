# GDC STYLE AI Kit — what each assistant can really do

The Kit works through ONE local command, `gdc-style-ai`, shipped inside GDC STYLE Client (`GDC STYLE Client.app/Contents/Helpers/gdc-style-ai`). It reads JSON and answers JSON. It never contacts a server, never needs Python and never runs with administrator rights.

| Assistant | Native install | What the Kit provides | Needs from you |
|---|---|---|---|
| Claude Code | Yes — a skill folder (`~/.claude/skills/gdc-style-pipeline/`), installed from the Client's AI Ready screen | Skill + references; the assistant runs the helper itself | Allow it to run the helper when it asks |
| Codex | Yes — a skill folder (`~/.codex/skills/gdc-style-pipeline/`), installed from the Client's AI Ready screen | Same skill; the assistant runs the helper itself | Allow it to run the helper when it asks |
| ChatGPT | **No native install.** | `portable/chatgpt/` instructions to paste into a custom GPT or project, plus the schemas and examples as knowledge files | A custom GPT cannot run a local command: you run the helper and paste the JSON answer back, or use a ChatGPT product that can run local commands |
| Gemini | **No native install.** | `portable/gemini/` instructions to paste into a Gem, plus the schemas and examples | Same: you run the helper and paste its answer back |
| Any other agent or script | n/a | `portable/INSTRUCTIONS.generic.md` and `portable/PROTOCOL.md` | The agent must be able to run a local command or process JSON |

## What the assistant can do

- read the public catalogue (products, public controls, ranges, cameras, working profiles) and, from the Client, what is installed and covered (Demo, Full or not covered);
- build a **Pipeline Recipe v2**, validate order, domains and parameters with the real engine, and produce a readable plan with the exact steps for you in DaVinci Resolve;
- refuse unsafe requests with stable codes.

## What it cannot do (and will never be able to do)

- Apply nodes inside DaVinci Resolve. The Resolve scripting API cannot create OpenFX nodes or set OpenFX parameters, so **you** mount the nodes and enter the values from the plan. "Apply" is a simulation that records the plan and the steps.
- Change editions, licences, rights or keys; remove the Demo watermark; turn Demo into Full; copy or modify Full packages; obtain private addresses. These operations do not exist.
- Confirm on your behalf: the confirmation is typed by you, in your own terminal.

GDC Input Transform and GDC Linear to Log follow the same rule as every other tool: Demo (watermark) without a licence, Full with a valid right; expiry or revocation returns them to Demo.
