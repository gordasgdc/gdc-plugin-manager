# GDC STYLE AI protocol (provider-neutral)

One local command: `gdc-style-ai request --request - --compact` (path printed by GDC STYLE Client → AI Ready; default `/Applications/GDC STYLE Client.app/Contents/Helpers/gdc-style-ai`). JSON in on standard input, JSON out on standard output.

Request: `{"schema":"gdc.ai-request/1","op":"<op>", ...}`; ops: `capabilities`, `catalog` (`product?`, `sinceHash?`), `inventory`, `build` (`spec`), `validate` (`recipe`), `plan` (`recipe`, `lang?`, `detail?` full|summary), `apply` (`recipe`, `confirm`). Response: `{"schema":"gdc.ai-response/1","ok":bool,"result":…,"issues":[{"level","code","path","message"}]}`. Exit code: 0 ok, 1 refused, 2 internal, 3 target not delivered, 4 no terminal.

Rules: unknown fields are refused; requests cannot carry licences, keys, tokens (except the confirmation token given by the person), addresses, paths or instructions-like text; the person confirms by running `gdc-style-ai confirm` in a terminal; `apply` is a simulation. Schemas: `../schemas/`. Examples: `../examples/`. Error codes: `../schemas/ai_error_codes.json`.
