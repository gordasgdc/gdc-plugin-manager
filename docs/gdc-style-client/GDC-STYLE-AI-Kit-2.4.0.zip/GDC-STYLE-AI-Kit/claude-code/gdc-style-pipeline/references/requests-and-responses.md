# Requests and responses

Every request: `{"schema": "gdc.ai-request/1", "op": "<operation>", ...}`; optional `requestId` (letters, digits, dot, dash, underscore, up to 48). Unknown fields are refused. Every response: `{"schema": "gdc.ai-response/1", "ok": true|false, "result": ..., "issues": [{"level", "code", "path", "message"}]}`. The messages are fixed templates; nothing you wrote is echoed back.

## capabilities / catalog / inventory

```json
{"schema": "gdc.ai-request/1", "op": "capabilities"}
{"schema": "gdc.ai-request/1", "op": "catalog", "product": "optics"}
{"schema": "gdc.ai-request/1", "op": "catalog", "sinceHash": "<catalogHash from your last catalog answer>"}
{"schema": "gdc.ai-request/1", "op": "inventory"}
```
Every catalog answer carries `catalogHash`. Send it back as `sinceHash`: if the catalogue is unchanged you get only `{"unchanged": true, "catalogHash": …}`. Read the catalogue once per session.

`inventory` answers, per product, the installed working profiles and the state of the rights as `demo`, `full` or `uncovered`. It reports; it cannot change anything.

## build

```json
{"schema": "gdc.ai-request/1", "op": "build", "spec": {
  "id": "docu-logc3-demo", "title": "Interior documentary (LogC3, Demo)", "language": "en",
  "source": {"camera": "ARRI ALEXA", "gamut": "ARRI Wide Gamut 3", "gamma": "ARRI LogC3 (EI 800)"},
  "workingProfile": "awg3-logc3-ei800",
  "management": {"mode": "gdc-managed", "camera": "arri-logc3-ei800.awg3"},
  "tools": [{"product": "exposure-balance", "params": {"v3eExposure": 0.15}}, {"product": "look", "params": {"v3lLook": 0}}],
  "output": {"provider": "gdc", "params": {"v3dProfile": "Natural"}}}}
```
Tool `edition` is `demo` (default) or `full`. `pipelineEditions` (`inputTransform`, `linearToLog`: `demo` (default) or `full`) sets the edition of GDC Input Transform and GDC Linear to Log, which `build` adds by itself; they are licensable like any tool. Do not list them in `tools`. For Resolve-managed colour use `"management": {"mode": "resolve-managed", "method": "color-management|color-space-transform|aces-input-transform", "delivers": "linear|log"}`. The order you give inside a stage is kept; if it is wrong the engine says so (`V3P-ORDER` and related codes). The answer carries `recipe` (Recipe v2) and the verdict.

## validate

```json
{"schema": "gdc.ai-request/1", "op": "validate", "recipe": { "...": "Recipe v2" }}
```

## plan

```json
{"schema": "gdc.ai-request/1", "op": "plan", "recipe": { "...": "Recipe v2" }, "lang": "en"}
{"schema": "gdc.ai-request/1", "op": "plan", "recipe": { "...": "Recipe v2" }, "lang": "en", "detail": "summary"}
```
`"detail": "summary"` returns the same `planHash` (and rights, blockers, `humanSteps`) without `planText` and `stages`: use it to re-check after small edits. The plan a person confirms must be the last **full** plan.
Result: `planHash`, `planText`, `stages`, `rights` (per element: installed, rights, status), `applyReady`, `applyBlockers`, `humanSteps`. The plan is produced even when blockers exist so the colourist can see what is missing.

## apply (simulation)

```json
{"schema": "gdc.ai-request/1", "op": "apply", "recipe": { "...": "same recipe as the plan" },
 "lang": "en", "confirm": {"planHash": "<64 hex from plan>", "token": "<token the person gave you>"}}
```
Without a valid `confirm` nothing is applied. If the recipe, the installed products or the rights change, ask for a new `plan`, and for a new confirmation. `target` can only be `dry`.
